import argparse
import csv
from sequence_1 import score_exact, score_approximatif, normalisation, decision, besoin_normalisation
#!/usr/bin/env python3
# La ligne ci-dessus permet d'exécuter le script sans préciser d'interpréteur.
# Par exemple, si le script est exécutable (chmod +x couplage.py), on peut l'exécuter directement avec ./couplage.py

# Fichier: couplage.py
# Auteur: Atelier Python, master TNAH 2024 de l'École nationale des chartes
# Description: Code complet de l'outil de couplage d'enregistrements en ligne de commande.
# License: domaine public

def charger_enregistrements(chemin: str) :
    with open(chemin, "r") as f:
        return list(csv.reader(f, delimiter=','))

def compter_lignes(liste:list) -> str :
    print(liste)
    nombre = 0
    for row in liste :
        nombre+=1
    return str(nombre)

def main():
    #print("je suis executé comme programme principal") #ne sert à rien
    parser = argparse.ArgumentParser( 
        prog='AtelierTNAH',
        description="Comparaisons d'enregistrements textuels",
        epilog='Programme terminé')  # création d'une instance de la classe ArgumentParser
    
    parser.add_argument('fichier1', type=str, help='Sélectionnez le premier fichier à coupler.') #ajout d'un premier argument positionnel avec texte pour -h
    parser.add_argument('fichier2', type=str, help='Sélectionnez le deuxième fichier à coupler.')  #ajout d'un deuxième argument positionnel avec texte pour -h
    
    args = parser.parse_args()

    fichier1 = args.fichier1 # argument dans une variable
    fichier2 = args.fichier1
    enregistrements1 = charger_enregistrements(fichier1) # chargement du csv dans une liste
    enregistrements1_header = enregistrements1[0] # on stocke les titres de colonnes
    enregistrements1 = enregistrements1[1:] # on stocke le reste du contenu du csv

    enregistrements2 = charger_enregistrements(fichier2)
    enregistrements2_header = enregistrements2[0]
    enregistrements2 = enregistrements2[1:]

    print(f"deux premières lignes du fichier 1 : \n {enregistrements1_header} \n {enregistrements1[0]}")
    print(f"deux premières lignes du fichier 2 : \n {enregistrements2_header} \n {enregistrements2[0]}")
    print("lignes fichier 1 : ", compter_lignes(enregistrements1))
    print("lignes fichier 2 : ",compter_lignes(enregistrements2))

    #print(f"fichier 1 : {fichier1},  fichier 2 : {fichier2}")

def couplage(liste1: list, liste2: list):
    couples = []

    if score_exact(liste1, liste2) : 
        seuil = 0

    if besoin_normalisation(liste1) == True :
        for e1 in liste1 :
            liste1_normalisee = [normalisation(chaine1) for chaine1 in e1]
                

    if besoin_normalisation(liste2) == True :
        for e2 in liste2 :
            liste2_normalisee = [normalisation(chaine2) for chaine2 in e2]

    if compter_lignes(liste1_normalisee) == compter_lignes(liste2_normalisee):
        
        score_approximatif(liste1_normalisee,liste2_normalisee)            

if __name__ == "__main__": # les fonctions peuvent donc être définies où on veut dans le doc
    main()
